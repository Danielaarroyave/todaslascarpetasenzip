
mes=(input("ingrese un mes: ").lower())
if mes=="enero" or mes=="febrero" or mes=="marzo":
    print("es invierno")
elif mes=="abril" or mes=="mayo" or mes=="junio":
    print("es verano")
elif mes=="julio" or mes=="agosto" or mes=="septiembre":
    print("es otoño")
elif mes=="octubre" or "noviembre" or mes=="dicimebre":
    print("es primavera")
else :
    print("no es valido")
