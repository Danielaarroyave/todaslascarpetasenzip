edad=(int(input("ingresa tu edad: ")))

if edad <= 14:
    print ("eres niño")
elif edad >=15 and edad <=28:
    print ("eres joven")
elif edad >=29 and edad <=60:
    print ("eres adulto")
elif edad >60:
    print ("eres adulto mayor")
else :
    print("opcion invalida")

