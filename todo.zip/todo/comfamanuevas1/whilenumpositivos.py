numero=0
suma=0

while( numero >= 0):
    numero=(int(input("ingrese un numero: ")))
    if numero >=0 :
        suma= suma + numero
        print (f"el resultado es: {suma}")
    else :
        print ("fin")

