#una lista es una variable

from xmlrpc.client import SafeTransport


numeros=[1,2,3,4,5]
nombres=["harold","harold","harold","harold","harold","sara","carlos","dani"]

'''print(numeros)
print(numeros[4])'''

#recorrer una lista

#for con un rango - indices
cont = 0
for i in range(len(nombres)):
    if nombres[i] == "harold" or nombres[i] == "sara":
        cont = cont + 1
        print(nombres[i])
print(cont)

#for con una lista
'''for nombre in nombres:
    if nombre == "harold":
        print(nombre)'''
