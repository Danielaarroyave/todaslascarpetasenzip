limite= (int(input("ingrese el numero: ")))
salto= (int(input("ingrese el salto: ")))

for i in range(0, limite, salto):
    
    print(i, end=", ")