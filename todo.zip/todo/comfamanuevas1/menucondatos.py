'''Codificar un programa que presente un menú de 4 opciones y reciba un numero natural  para realizar las siguientes operaciones:
	
	0: Salida
	1: Encuentre si el número es múltiplo de 2
	2: Encuentre la raíz cuadrada del número
   	3: Sume 100 al número ingresado
 	4: Eleve a la 2 el número ingresado
'''

opcion=1

while opcion !=0:
    print("opcion 0. Salir") 
    print("opcion 1. Encuentre si el número es múltiplo de 2")
    print("opcion 2. Encuentre la raíz cuadrada del número")
    print("opcion 3. Sume 100 al número ingresado")
    print("opcion 4. Eleve a la 2 el número ingresado")
    opcion= (int(input("ingrese una opcion: ")))
    if opcion == 1 :
        valor= (int(input("ingrese un numero: ")))
        valor= valor % 2 == 0
        print(f"el valor  es: {valor}")
    elif opcion == 2 :
        valor= (int(input("ingrese un numero: ")))
        valor= valor ** 0.5
        print(f"el valor  es: {valor}")
   


