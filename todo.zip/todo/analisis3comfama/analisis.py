import pandas as pd
data = pd.read_csv("./empleados.csv")
print (data)

filtro= data.head(10)
print (filtro)
