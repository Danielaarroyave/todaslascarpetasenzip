import matplotlib.pyplot as plt
años=[2013,2014,2015,2016,2017,2018,2019,2020,2021,2022]
consumidores=[400,10000,8000,4500,4000,5000,4800,12000,14000,10000]
colors=["#CC7CE7"," #C609F2 "," #F209C6 "," #EB1D34 "," #16D9F4 "," #16F4CF "," #16F486 "," #ECF416 "," #F42E16 "," #B799D0 "]


plt.bar(años,consumidores,color=colors)
plt.show()