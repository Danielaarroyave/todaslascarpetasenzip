#importando libreria
import matplotlib.pyplot as plt

#1 tener una fuente de datos
barrios=["calasanz","laureles","castilla","belen","robledo","boston","buenos aires"]
poblacion=[12000,25000,40000,100000,200000,50000,6000,250000,10000,5000]

barriosBello=["la cumbre","santa ana","niquia","bella vista","paris","camacol","cabañas ","barrio obrero","navarra","pacheli"]
poblacion=[300000,12000,100000,50000,25000,50000,6000,250000,10000,5000]

#2. procedo  a utilizar el matplotlib para generar la grafica

plt.plot(barrios,poblacion,marker="o")
plt.xlabel("Barrios de Medellín")
plt.ylabel("Población")
plt.title("Densidad población Medellín 2023")

plt.savefig("linea.png")
plt.show()
