#ENTRADAS DEL PROBLEMA
niveldeagua =int (input("digite el nivel del agua"))

#EVALUANDO CAMINOS MULTIPLES

if niveldeagua <= 100 :
    print("bajo nivel de agua: ") 
elif niveldeagua >100 and niveldeagua <400:
    print("operación normal: ")
elif niveldeagua >= 400:
    print("peligro")
else:
    print("nivel de agua no valido: ")

