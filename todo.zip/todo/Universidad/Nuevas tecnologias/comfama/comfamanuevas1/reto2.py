mes= input("en que mes estas: ")

if mes== "marzo" or mes== "arbril" or mes== "mayo":
    print("estamos en primavera")
elif mes== "junio" or mes== "julio" or mes== "agosto":
    print("estamos en verano")
elif mes== "septiembre" or mes== "octubre" or mes== "noviembre":
    print("estamos en otoño")
elif mes== "diciembre" or mes== "enero" or mes== "febrero":
    print("estamos en invierno")
else:
    print("vuelve a introducir el mes: ")