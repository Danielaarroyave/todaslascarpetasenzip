variablecontroladora=0
while variablecontroladora<10:
    print("pagueme dinero")
    variablecontroladora=variablecontroladora+7