###reto 3 Recibir dos números y determinar cual es mayor
#ingrese información por teclado

numero1= int(input ("ingrese un número entero: "))

numero2= int(input ("ingrese un número entero: "))

if numero1 > numero2 :
    print ("El número mayor es: " "resultado")
else :
    print ("numero2 es menor a numero1")
