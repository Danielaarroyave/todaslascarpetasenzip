##reto2 Recibir un numero en teclado y determinar si este es múltiplo de 5
 #ingrese información por teclado

num1= int(input ("ingrese un número entero: "))
if num1 % 5 == 0 :
 print("es multiplo de 5")
else :
 print ("no es multiplo de 5") 