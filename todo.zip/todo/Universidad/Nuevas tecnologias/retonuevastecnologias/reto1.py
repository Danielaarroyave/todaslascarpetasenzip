### reto 1 Recibir un numero en teclado y determinar si este es múltiplo de 3

#ingrese información por teclado

num= int(input ("ingrese un número entero: "))
if num % 3 == 0 :
 print("El",num,"Si es multiplo de 3")
else :
  print ("El",num,"no es multiplo de 3") 
 
#prueba1








