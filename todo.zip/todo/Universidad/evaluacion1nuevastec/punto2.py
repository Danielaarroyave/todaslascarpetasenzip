####  Juan tiene N cantidad de pesos, Camila tiene la mitad de lo que posee Juan y Ricardo tiene la mitad de lo que poseen Camila y Juan Juntos. ¿Puede PYTHON ayudarme a calcular la cantidad de dinero de los 3?

pesosjuan= int (input ("ingrese cuantos pesos tiene juan: "))



pesosjuan= int (pesosjuan)
camila= int ((pesosjuan) / 2)
ricardo= int ((camila + pesosjuan) / 2)

print ("juan tiene",pesosjuan,"pesos")

print ("camila tiene",camila,"pesos")
print ("ricardo tiene",ricardo,"pesos")