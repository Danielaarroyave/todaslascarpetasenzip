import pandas as pd

empleados=pd.read_csv("./empleados.csv")

analistasbajocosto=empleados[(empleados["salario"]<=5000000) & (empleados["cargo"]=="analista1")].head(20)

#exportando un dataframe hacia html

archivoHTML=analistasbajocosto.to_html()
archivoGenerado=open("bajocosto.html","w")
archivoGenerado.write(archivoHTML)
archivoGenerado.close()